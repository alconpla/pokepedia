<?php $__env->startSection('content'); ?>

<style type="text/css">
    .table td, .table th{
        vertical-align: middle;
        text-align:center;
        padding: .55rem;
    }
    
    .btn {
        margin-right: 10px;
    }
    
    .table thead th {
        text-align:center;
    }
</style>

<div class="container">
    <div class="row">
        <div class="col-md-12">
            <?php if(Session::has('success')): ?>
			<div class="alert alert-info">
				<?php echo e(Session::get('success')); ?>

			</div>
			<?php endif; ?>
			<div class="d-flex justify-content-between">
			    <h2>Foro</h2>
			       <div>
			           <a href="<?php echo e(action('PostController@create')); ?>" class="btn btn-success btn-sm">Add post</a>
			       </div>
			</div>
			
            <table class="table table-hover">
                <thead>
                <tr>
                  <th scope="col">#ID</th>
                  <th scope="col">Subject</th>
                  <th scope="col">User</th>
                  <th scope="col">Posted at</th>
                  <th scope="col">Options</th>
                </tr>
                </thead>
                <tbody>
                <?php $__currentLoopData = $post; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                  <th scope="row"><?php echo e($p->id); ?></th>
                  <td><?php echo e($p->subject); ?></td>
                  <td><?php echo e($p->user->name); ?></td>
                  <td><?php echo e($p->created_at); ?></td>
                  <td><a href="<?php echo e(route('post.show', $p->id)); ?>" class="btn btn-primary btn-sm">View</td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </tbody>
            </table>
            <div class="d-flex justify-content-center">
                <?php echo e($post->links()); ?>

            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/ubuntu/environment/web/pokepedia/resources/views/post/index.blade.php ENDPATH**/ ?>