<?php $__env->startSection('content'); ?>

<div class="container">
    <div class="row">
        <div class="col-md-12">
            <h2>Pokemon detail</h2>
        </div>
        <div class="col-md-7">
            <img height="500" class="img-fluid" src="https://pokeres.bastionbot.org/images/pokemon/<?php echo e($pokemon->id); ?>.png"></img>
        </div>
        <div class="col-md-4">
            <p><strong>Name:</strong> <?php echo e($pokemon->name); ?></p>
            <p><strong>Height:</strong> <?php echo e($pokemon->height); ?></p>
            <p><strong>Weight:</strong> <?php echo e($pokemon->weight); ?></p>
            <a class="btn btn-secondary" href="<?php echo e(route('pokemon.index')); ?>">Go back</a>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/ubuntu/environment/web/pokepedia/resources/views/pokemon/detail.blade.php ENDPATH**/ ?>