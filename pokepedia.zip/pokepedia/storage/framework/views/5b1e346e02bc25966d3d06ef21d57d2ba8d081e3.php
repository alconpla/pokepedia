<?php $__env->startSection('content'); ?>

<div class="container">
    <div class="row">
        <div class="col-md-12">
            <h2>Create Post</h2>
            
            <form action="<?php echo e(route('post.store')); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <div class="form-group">
                    <input type="text" class="form-control" id="subject" name="subject" placeholder="Subject...">
                </div>
                <div class="form-group">
                    <label for="idpokemon">Select a pokemon</label>
                    <select name="idpokemon" class="form-control" name="idpokemon">
                        <?php $__currentLoopData = $pokemon; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pokemon): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($pokemon->id); ?>"><?php echo e($pokemon->id . '. ' . $pokemon->name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
                <div class="form-group">
                    <textarea class="form-control" id="content" name="content" placeholder="Content..."></textarea>
                </div>
                <a class="btn btn-secondary" href="<?php echo e(route('post.index')); ?>">Go back</a>
                <input type="submit" class="btn btn-primary" value ="Create">
            </form>

        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/ubuntu/environment/web/pokepedia/resources/views/post/create.blade.php ENDPATH**/ ?>