<?php $__env->startSection('content'); ?>

<div class="container">
    <div class="row">
        <div class="col-md-12">
            <h2>Post detail</h2>
        </div>
        <div class="col-md-3">
            <img height="200"src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/<?php echo e($post->pokemon->id); ?>.png"></img>
        </div>
        <div class="col-md-9">
            <p><strong>Subject:</strong> <?php echo e($post->subject); ?></p>
            <p><strong>User:</strong> <?php echo e($post->user->name); ?></p>
            <p><strong>Posted at:</strong> <?php echo e($post->created_at); ?></p>
            <p><strong>Content:</strong> <?php echo e($post->content); ?></p>
            <a class="btn btn-secondary" href="<?php echo e(route('post.index')); ?>">Go back</a>
        </div>
    </div>
    <hr>
    <div class="row">
        <div class="col-md-6">
            <?php $__currentLoopData = $comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $com): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="card mb-2">
              <div class="card-body">
                <blockquote class="blockquote mb-0">
                  <p><?php echo e($com->content); ?></p>
                  <footer class="blockquote-footer"><?php echo e($com->user->name); ?></footer>
                </blockquote>
              </div>
            </div>
           <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
        <div class="col-md-6">
            <form action="<?php echo e(route('comment.store')); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <div class="form-group">
                    <textarea class="form-control" id="content" name="content" placeholder="Comment anything..."></textarea>
                    <input type="hidden" name="idpost" value="<?php echo e($post->id); ?>">
                </div>
                <input type="submit" class="btn btn-primary" value="Comment">
            </form>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/ubuntu/environment/web/pokepedia/resources/views/post/detail.blade.php ENDPATH**/ ?>