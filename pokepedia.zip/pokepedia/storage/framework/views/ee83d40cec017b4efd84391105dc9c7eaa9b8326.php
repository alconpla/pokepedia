<?php $__env->startSection('content'); ?>

<style type="text/css">
    .table td, .table th{
        vertical-align: middle;
        text-align:center;
        padding: .55rem;
    }
    
    .btn {
        margin-right: 10px;
    }
    
    .table thead th {
        text-align:center;
    }
</style>

<div class="container">
    <div class="row">
        <div class="col-md-12">
            <?php if(Session::has('success')): ?>
			<div class="alert alert-info">
				<?php echo e(Session::get('success')); ?>

			</div>
			<?php endif; ?>
			<div class="d-flex justify-content-between">
			    <h2>Pokedex</h2>
			       <div>
			           <a href="<?php echo e(action('PokemonController@create')); ?>" class="btn btn-success btn-sm">Add pokemon</a>
			       </div>
			</div>
			
            <table class="table table-hover">
                <thead>
                <tr>
                  <th scope="col">#ID</th>
                  <th scope="col">Name</th>
                  <th scope="col">Height</th>
                  <th scope="col">Weight</th>
                  <th scope="col">Image</th>
                  <th scope="col">Options</th>
                </tr>
                </thead>
                <tbody>
                <?php $__currentLoopData = $pokemon; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $poke): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                  <th scope="row"><?php echo e($poke->id); ?></th>
                  <td><?php echo e($poke->name); ?></td>
                  <td><?php echo e($poke->height); ?></td>
                  <td><?php echo e($poke->weight); ?></td>
                  <td> <img src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/<?php echo e($poke->id); ?>.png"></td>
                  <td><a href="<?php echo e(route('pokemon.show', $poke->id)); ?>" class="btn btn-primary btn-sm">View</a><a href="#" class="btn btn-danger btn-sm">Delete</a></td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </tbody>
            </table>
            <div class="d-flex justify-content-center">
                <?php echo e($pokemon->links()); ?>

            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/ubuntu/environment/web/pokepedia/resources/views/pokemon/index.blade.php ENDPATH**/ ?>